import 'package:flutter/material.dart';

class RecentlyReceivedPage extends StatelessWidget {
  Widget createLogo() {
    return Container(
      child: SizedBox(
        child: Image.asset('assets/images/sadul.jpg'),
        height: 70,
      ),
      margin: EdgeInsets.only(left: 15, top: 115),
    );
  }

  Widget createText() {
    return Text(
      'Recently received',
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 20,
      ),
    );
  }

  Widget letterHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
            margin: EdgeInsets.only(top: 10, left: 10),
            child: Image.asset(
              'assets/images/sadul.jpg',
              width: 10,
            )),
        //Spacer(flex: 10,),

        Image.asset(
          'assets/images/sadul.jpg',
          width: 50,
        ),
      ],
    );
  }

  Widget createLetter() {
    return SizedBox(
      height: 250,
      width: 150,
      child: Card(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            letterHeader(),
            Container(
              margin: EdgeInsets.all(10),
              child: Text(
                'Hej! (this is hello in Danish) I\'m Jens from Copenhagen,Denmark...',
              ),
            ),
            Text(
              'Jens',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(
              'Today 6.15 PM',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget createLetterList() {
  //   return Container(
  //      height: 300,
  //     child: ListView.builder(
  //       scrollDirection: Axis.horizontal,
  //       itemCount: 5,
  //       itemBuilder: (BuildContext context, int index) {
  //         return createLetter();
  //       },
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          createLogo(),
          createText(),
          createLetter(),
        ],
      ),
    );
  }
}
